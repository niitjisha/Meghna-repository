package com.niit.eCart;


import java.util.Date;
import java.util.Scanner;

public class ConstructorMethod {
	int empId,empPhone;
	String empName;
	public void accept()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the details:");
		empId=sc.nextInt();
        empName=sc.next();
        empPhone=sc.nextInt();
	}
    public void display()
    {
    	System.out.println("Employee ID is:"+empId);
    	System.out.println("Employee name is:"+empName);
    	System.out.println("Employee joining date:"+new Date());	
    }
	public static void main(String[] args) {
		ConstructorMethod constructormethod = new ConstructorMethod();
		constructormethod.accept();
		constructormethod.display();	

	}

}
