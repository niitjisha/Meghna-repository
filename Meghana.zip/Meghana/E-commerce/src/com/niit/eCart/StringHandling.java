package com.niit.eCart;

public class StringHandling 
{
   
	void display()
	{
		int id;
		   String name,addrs; 
		   id=201;
		   name="RAHUL";
		   addrs="MVM";
		   System.out.println("Student ID is:"+id);
		   System.out.println("Student name is:"+name);
	}
	public static void main(String[] args) 
	{
	  StringHandling stringhandling = new StringHandling();
	  stringhandling.display();
	  int marks;
	  marks=70;
	  System.out.println("Marks:"+marks);

	}

}
