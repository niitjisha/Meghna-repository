package execptionPack;

public class StudentImpl extends StudentExmp
{
	String id;
	String name;
	public void addStudent()
	{
		id="S171113400063";
		name="Rahul";
	}
    public void printStudent()
    {
    	System.out.println("Student ID:"+id);
    	System.out.println("Student name:"+name);
    }
	public static void main(String[] args)
	{
		StudentImpl stimpl= new StudentImpl();
		stimpl.addStudent();
		stimpl.printStudent();

	}

}
