package execptionPack;
class Manager
 {
	int mId;
	String mName;
	
  void addManager()
  {
	  mId=201;
	  mName="Rahul";
   }
  void displayManager()
  {
	 System.out.println("Manager ID is:"+mId);
	 System.out.println("Manager name is:"+mName);
  }
}
  
 class Clerk extends Manager
 {
	int cId;
	String cName;
	void addClerk()
	{
	   cId=10;
	   cName="Arun";
	}
	void displayClerk()
	{
		System.out.println("Clerk ID is:"+cId);
		System.out.println("Clerk Name is:"+cName);
	}
  @Override
  void addManager()
  {
	  for(int i=65;i<=90;i++)
	  {
		  System.out.println((char)i);
	  }
  }
 }  
public class ExmpleClass 
{
	public static void main(String[] args) 
	{
		Clerk c = new Clerk();
		c.addManager();
		c.displayManager();
		c.addClerk();
		c.displayClerk();

	}

  }

