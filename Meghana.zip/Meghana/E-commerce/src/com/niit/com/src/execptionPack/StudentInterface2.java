package execptionPack;

public interface StudentInterface2 
{

	public abstract void addStudent();
	public abstract void printStudent();

	}


