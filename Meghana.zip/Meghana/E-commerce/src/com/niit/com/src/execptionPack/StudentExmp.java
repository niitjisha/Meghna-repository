package execptionPack;

public abstract class StudentExmp
{

	public abstract void addStudent();
	public abstract void printStudent();
	
 	public void calculate()
	{
		int a,b;
		a=10;
		b=15;
		System.out.println(a);
		System.out.println(b);
	} 
		

}
