package execptionPack;

public class StudentInterface implements StudentInterface2
{
	String id,name;
	public void addStudent()
	{
		id="S171113400063";
		name="Rahul";
	}
    public void printStudent()
    {
    	System.out.println("Student ID:"+id);
    	System.out.println("Student name:"+name);
    }
	public static void main(String[] args)
	{
		StudentInterface stin= new StudentInterface();
		stin.addStudent();
		stin.printStudent();
 }
}