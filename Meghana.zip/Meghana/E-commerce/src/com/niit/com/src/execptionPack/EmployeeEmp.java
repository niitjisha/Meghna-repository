package execptionPack;

public class EmployeeEmp 
{
  int id;
  String name;
  public static void main(String[] args)
  {
	EmployeeEmp employeeemp = new EmployeeEmp();
	employeeemp.accept();	
  }
 void accept()
 {
	 try
	 {
		 int ar[]=new int[10];
		 ar[0]=20;
		 ar[1]=25;
		 System.out.println(ar[14]);
	 }
	 catch(Exception e)
	 {
		 System.out.println("Exception handled!");
	 }
	 finally
	 {
		 System.out.println("Value of i:"+id);
		 int a,b;
		 a=15;
		 b=20;
		 b+=50;
		 a-=80;
		 System.out.println(a);
		 System.out.println(b);
	 }
			 
	 }
 }