package com.niit.kart;

public class Pack {

	public static void main(String[] args) {
	
	}

}
