package com.niit.kart;

import java.util.Scanner;

import com.niit.eCart.ConstructorMethod;

public class CallingFunction
{
	public static void main(String[] args)
	{
	 
	 	int a,b,c;
	 	Scanner sc=new Scanner (System.in);
	 	System.out.println("enter the value of a");
	 	a=sc.nextInt();
	 	System.out.println("enter the value of b");
	 	b=sc.nextInt();
	 	c=a+b;
	 	System.out.println("value of a:"+a);
	 	System.out.println("value of b:"+b);
	 	System.out.println("Addition="+c);
	 	
	 	
	 ConstructorMethod constructormethod = new ConstructorMethod();
	 constructormethod.accept();
	 constructormethod.display();	
	}
}